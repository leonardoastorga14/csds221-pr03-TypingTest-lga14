# pr03-TypingTest-csds221-lga14

A Pen created on CodePen.io. Original URL: [https://codepen.io/leonardoastorga14/pen/jOemRRa](https://codepen.io/leonardoastorga14/pen/jOemRRa).

